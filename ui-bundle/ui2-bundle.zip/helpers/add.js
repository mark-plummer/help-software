'use strict'

module.exports = (a, b) => (a || 0) + (b || 0)
